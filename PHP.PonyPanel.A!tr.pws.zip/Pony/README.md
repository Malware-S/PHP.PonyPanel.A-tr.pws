# Pony
Pony 2.0 Stealer

Uploaded to GitHub for those want to analyse the code.
